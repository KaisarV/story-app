package com.kai.storyapp.model.request

data class LoginRequest (
    var email: String,
    var password: String,
)